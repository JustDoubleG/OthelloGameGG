import javax.swing.JFrame;

public class ViewRecordsUI {

	public ViewRecordsUI() {
		
		JFrame records = new JFrame("Records");
		records.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		records.getContentPane().setLayout(null);
		records.setSize(800, 500);
		records.setVisible(true);
		
		//need to add in the records from database
		
	}
	
}