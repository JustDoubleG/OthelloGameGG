
public class ZPlayer {
	private int movesTaken, score, numberValue;
	private String username;
	private String password;
	boolean hadPossibleMoves;
	int completionOfTurn;
	boolean isComputer;
	
	
	//Default constructor initializes user-name and score for a new player
	ZPlayer(String newUsername){
		this.username = newUsername;
		this.password = "";
		this.score = 2;
		this.movesTaken = 0;
		this.hadPossibleMoves = false;
		this.numberValue = 0;
		this.completionOfTurn = 0;
	}
	ZPlayer(String name, String pass){
		this.username = name;
		this.password = pass;
		this.score = 2;
		this.movesTaken = 0;
		this.hadPossibleMoves = false;
		this.numberValue = 0;
		this.completionOfTurn = 0;
	}
	ZPlayer(){
		this.username = "TempName";
		this.password = "";
		this.score = 2;
		this.movesTaken = 0;
		hadPossibleMoves = false;
		numberValue = 0;
		completionOfTurn = 0;
	}
	//**************************************************************************************************//
	public void setCompletionOfTurn(int i) {
		this.completionOfTurn = i;
	}
		
	public int getCompletionOfTurn() {
		return this.completionOfTurn;
	}
	//**************************************************************************************************//

	//GET AND SET USERNAME
	public String getUsername() {
		return this.username;
	}
	public void setUsername(String u) {
		this.username = u;
	}
	//**************************************************************************************************//
	//GET AND SET PASSWORD
	public String getPassword() {
		return this.password;
	}
	public void setPassword(String p) {
		this.password = p;
	}
	
	//**************************************************************************************************//
	//GET AND SET SCORE
	public int getScore() {
		return this.score;
	}
	public void setScore(int s) {
		this.score = s;
	}
	//**************************************************************************************************//
	//GET AND SET MOVES TAKEN
	public int getMovesTaken() {
		return this.movesTaken;
	}
	public void setMoves(int num) {
		this.movesTaken = num;
	}
	//**************************************************************************************************//
	//GET AND SET MYTURN
	//HadPossibleMoves = false means don't have any 3s for that player
	//HadPossibleMoves = true means they do have 3s for that player
	public boolean getHadPossibleMoves() {
		return this.hadPossibleMoves;
	}
	public void setHadPossibleMoves(boolean my) {
		this.hadPossibleMoves = my;
	}
	//**************************************************************************************************//
	//GET AND SET NUMBERVALUE
	public int getNumberValue() {
		return this.numberValue;
	}
	public void setNumberValue(int v) {
		if (v < 1 || v > 2)
			System.out.println("Not a valid color");
		else 
			numberValue = v;
	}
	//**************************************************************************************************//
	public int setPassword(String oldPassword, String newPassword) {
		if(oldPassword == this.password) {
			this.password = newPassword;
			return 1;//Return 1 so that the program knows it is successful
		}
		else 
			return 0;//Return 0 so that the program knows it is unsuccessful
	}
	
	//**************************************************************************************************//
	//GET AND SET SCORE			Made by: Sean
	//Edited by:					Description: Manipulate isComputer
	public boolean getIsComputer() {
		if(this.username == "Computer") {
			this.isComputer = true;
		}
		else {
			this.isComputer = false;
		}
		return this.isComputer;
	}
	public void setIsComputer() {
		this.isComputer = true;
		//this.username = "Computer";
		
	}
	
	/*public void checkInfo(String uName, String Pwd) {
		if (uName == this.username) {
			if(Pwd == this.password) {
				this.valid = 1;
				return;
			}
		}else {
			return;
		}
	}
	public int getValidity(){
		return this.valid;
	}*/
	
}